class User:
    def __init__(self, user_id=None, username=None, password=None, role=None):
        self._user_id = user_id
        self._username = username
        self._password = password
        self._role = role

    def __str__(self):
        return f"User(user_id={self._user_id}, username={self._username}, role={self._role})"
class Client:
    def __init__(self, client_id=None, client_name=None, contact_info=None, policy=None):
        self._client_id = client_id
        self._client_name = client_name
        self._contact_info = contact_info
        self._policy = policy

    def __str__(self):
        return f"Client(client_id={self._client_id}, client_name={self._client_name})"
class Claim:
    def __init__(self, claim_id=None, claim_number=None, date_filed=None, claim_amount=None, status=None, policy=None, client=None):
        self._claim_id = claim_id
        self._claim_number = claim_number
        self._date_filed = date_filed
        self._claim_amount = claim_amount
        self._status = status
        self._policy = policy
        self._client = client

    def __str__(self):
        return f"Claim(claim_id={self._claim_id}, claim_number={self._claim_number})"
class Payment:
    def __init__(self, payment_id=None, payment_date=None, payment_amount=None, client=None):
        self._payment_id = payment_id
        self._payment_date = payment_date
        self._payment_amount = payment_amount
        self._client = client

    def __str__(self):
        return f"Payment(payment_id={self._payment_id}, payment_date={self._payment_date})"
import __init.__py
