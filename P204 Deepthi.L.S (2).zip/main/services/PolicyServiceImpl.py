from typing import List

class PolicyServiceImpl:
    def create_policy(self, policy) -> bool:
        print(f"Policy '{policy}' created")
        return True

    def get_policy(self, policy_id) -> object:
        print(f"Retrieved policy with ID: {policy_id}")
        return {"policy_id": policy_id, "policy_name": "Sample Policy"}

    def get_all_policies(self) -> List[object]:
        print("Retrieved all policies")
        return [{"policy_id": 1, "policy_name": "Sample Policy"}]

    def update_policy(self, policy) -> bool:
        print(f"Policy updated: {policy}")
        return True

    def delete_policy(self, policy_id) -> bool:
        print(f"Deleted policy with ID: {policy_id}")
        return True
