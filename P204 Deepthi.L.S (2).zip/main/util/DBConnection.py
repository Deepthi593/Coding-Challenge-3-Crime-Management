import pyodbc

import configparser
import pyodbc

class DBConnection:
    @staticmethod
    def get_connection():
        conn = None
        try:
            config = configparser.ConfigParser()
            config.read('config.ini')
            username = config['is1']['lsdeepthi']
            password = config['is1']['lsd123']

            conn = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};'
                'SERVER=LAPTOP-T4FVE489\SQLEXPRESS;'
                'DATABASE=is1;'
                f'UID={lsdeepthi};'
                f'PWD={lsd123}'
            )
            print("Connection successful")
        except Exception as e:
            print(f"Error: {e}")
        return conn
