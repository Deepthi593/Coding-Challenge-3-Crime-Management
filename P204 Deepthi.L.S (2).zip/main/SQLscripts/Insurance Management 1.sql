create database is1
use is1
CREATE TABLE Users (
    userId INT PRIMARY KEY IDENTITY(1,1),
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL
);
CREATE TABLE Clients (
    clientId INT PRIMARY KEY IDENTITY(1,1),
    clientName VARCHAR(100) NOT NULL,
    contactInfo VARCHAR(255) NOT NULL,
    policyId INT NOT NULL, 
    FOREIGN KEY (policyId) REFERENCES Policies(policyId) -- Assuming a Policy table exists
);
CREATE TABLE Claims (
    claimId INT PRIMARY KEY IDENTITY(1,1),
    claimNumber VARCHAR(50) NOT NULL,
    dateFiled DATE NOT NULL,
    claimAmount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) NOT NULL,
    policyId INT NOT NULL,
    clientId INT NOT NULL,
    FOREIGN KEY (policyId) REFERENCES Policies(policyId),  -- Assuming a Policy table exists
    FOREIGN KEY (clientId) REFERENCES Clients(clientId)
);
CREATE TABLE Payments (
    paymentId INT PRIMARY KEY IDENTITY(1,1),
    paymentDate DATE NOT NULL,
    paymentAmount DECIMAL(10, 2) NOT NULL,
    clientId INT NOT NULL,
    FOREIGN KEY (clientId) REFERENCES Clients(clientId)
);
CREATE TABLE Policies (
    policyId INT PRIMARY KEY IDENTITY(1,1),
    policyName VARCHAR(100) NOT NULL,
    policyDetails VARCHAR(255) NOT NULL
);
INSERT INTO Users (username, password, role)
VALUES 
    ('john_doe', 'password123', 'admin'),
    ('jane_smith', 'pass456', 'manager'),
    ('alice_johnson', 'alicepass789', 'user');
INSERT INTO Policies (policyName, policyDetails)
VALUES 
    ('Health Insurance', 'Comprehensive health coverage policy'),
    ('Car Insurance', 'Full coverage for all damages and third-party claims'),
    ('Life Insurance', 'Whole life insurance plan with beneficiaries');
INSERT INTO Clients (clientName, contactInfo, policyId)
VALUES 
    ('Acme Corp', '123 Main St, New York, NY', 1),
    ('Global Industries', '456 Industrial Ave, Chicago, IL', 2),
    ('Tech Innovators', '789 Silicon St, San Francisco, CA', 3);
INSERT INTO Claims (claimNumber, dateFiled, claimAmount, status, policyId, clientId)
VALUES 
    ('CLM001', '2024-01-10', 5000.00, 'Pending', 1, 1),
    ('CLM002', '2024-03-22', 10000.00, 'Approved', 2, 2),
    ('CLM003', '2024-05-15', 3000.00, 'Rejected', 3, 3);
INSERT INTO Payments (paymentDate, paymentAmount, clientId)
VALUES 
    ('2024-01-15', 2500.00, 1),
    ('2024-04-01', 5000.00, 2),
    ('2024-06-10', 1500.00, 3);
SELECT * FROM Users;
SELECT * FROM Clients;
SELECT * FROM Policies;
SELECT * FROM Claims;
SELECT * FROM Payments;

