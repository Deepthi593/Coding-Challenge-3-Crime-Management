# entities/__init__.py
from .entities import User, Client, Claim, Payment
from services.PolicyServiceImpl import PolicyServiceImpl
from util.DBConnection import DBConnection
from exceptions.PolicyNotFoundException import PolicyNotFoundException

if __name__ == "__main__":
    service = PolicyServiceImpl()

    try:
        # Example usage of service methods
        service.create_policy("New Health Policy")
        service.get_policy(1)
        service.get_all_policies()
        service.update_policy("Updated Health Policy")
        service.delete_policy(1)
    except PolicyNotFoundException as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
